package com.poly;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class J6D5Application {

    public static void main(String[] args) {
        SpringApplication.run(J6D5Application.class, args);
    }

}
