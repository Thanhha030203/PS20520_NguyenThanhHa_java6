package com.poly.j6d5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class J6D5ApplicationTests {

    @Test
    void contextLoads() {
    }

}
