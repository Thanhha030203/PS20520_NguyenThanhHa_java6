package com.fpoly.entity;

import java.util.HashMap;

public class StudentMap extends HashMap<String, Student>{

	private static final long serialVersionUID = 1L;

}
