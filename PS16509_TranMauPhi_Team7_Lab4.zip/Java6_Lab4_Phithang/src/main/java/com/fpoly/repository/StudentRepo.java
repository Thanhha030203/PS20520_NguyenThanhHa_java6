package com.fpoly.repository;

import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fpoly.entity.Student;
import com.fpoly.entity.StudentMap;

@Repository
public class StudentRepo {
	private RestTemplate rest = new RestTemplate();
	private String url = "https://java6fpoly-1bcdc-default-rtdb.firebaseio.com/student.json";
	
	public String getUrl(String key) {
		return url.replace(".json","/" + key + ".json");
	}
	
	public StudentMap findAll() {
		return rest.getForObject(url, StudentMap.class);
	}
	
	public Student findByKey(String key) {
		return rest.getForObject(getUrl(key), Student.class);
	}
	
	public String create(Student data) {
		HttpEntity<Student> entity = new HttpEntity<>(data);
		JsonNode resp = rest.postForObject(url, entity, JsonNode.class);
		return resp.get("name").asText();
	}
	
	public Student update(String key,Student data) {
		HttpEntity<Student> entity = new HttpEntity<>(data);
		rest.put(getUrl(key),data);
		return data;
	}
	
	public void delete(String key) {
		rest.delete(getUrl(key));
	}
	
	public static void main(String[] args) {
		StudentRepo dao = new StudentRepo();
		StudentMap list = dao.findAll();
		System.out.println(list);
	}
	
}
