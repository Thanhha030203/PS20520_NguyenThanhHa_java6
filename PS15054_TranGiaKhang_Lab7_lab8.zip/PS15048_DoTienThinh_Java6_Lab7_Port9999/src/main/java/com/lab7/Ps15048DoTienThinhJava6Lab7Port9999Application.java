package com.lab7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ps15048DoTienThinhJava6Lab7Port9999Application {

	public static void main(String[] args) {
		SpringApplication.run(Ps15048DoTienThinhJava6Lab7Port9999Application.class, args);
	}

}
