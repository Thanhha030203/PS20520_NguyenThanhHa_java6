package com.lab8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ps15054TranGiaKhangLab8Application {

	public static void main(String[] args) {
		SpringApplication.run(Ps15054TranGiaKhangLab8Application.class, args);
	}

}
