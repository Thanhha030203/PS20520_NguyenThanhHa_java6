package com.lab7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ps15048DoTienThinhJava6Lab7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
